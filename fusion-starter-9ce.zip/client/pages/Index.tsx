import { useCallback, useEffect, useMemo, useState, type CSSProperties } from "react";
import {
  ArrowDown,
  ArrowDownRight,
  ArrowUpRight,
  ExternalLink,
  Mail,
  Phone,
  X,
} from "lucide-react";
import { projects, skillGroups, type PortfolioProject } from "./portfolio-data";

type Theme = "dark" | "light";
type ProjectFilter = "All projects" | "Analytics" | "Machine learning" | "Product analytics" | "NLP";

const filters: ProjectFilter[] = ["All projects", "Analytics", "Machine learning", "Product analytics", "NLP"];
const navigation = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Projects", href: "#projects" },
  { label: "Skills", href: "#skills" },
  { label: "Experience", href: "#experience" },
  { label: "Contact", href: "#contact" },
];
const linkedInUrl = "https://www.linkedin.com/in/shivansh-srivastava-hireboost-workspace/";
const githubUrl = "https://github.com/shivansh-builds";
const introRoles = ["Hello", "Data Analyst", "SQL Developer", "Business Analyst", "Data Scientist"];
const profilePhoto = `${import.meta.env.BASE_URL}shivansh-profile.jpg`;

function ProjectPreview({ project }: { project: PortfolioProject }) {
  return (
    <div className={`project-preview preview-${project.visual}`} aria-hidden="true">
      <div className="preview-toolbar"><span><i /> CASE STUDY VIEW</span><span>ILLUSTRATIVE</span></div>
      <div className="preview-metrics">{project.previewMetrics.map((metric) => <div key={metric}><small>{metric}</small><b>—</b></div>)}</div>
      <div className="preview-chart">
        <div className="preview-chart-heading"><span>{project.visual === "fraud" ? "Alert review" : project.visual === "forecast" ? "Weekly pattern" : project.visual === "funnel" ? "Journey overview" : project.visual === "sentiment" ? "Feedback themes" : "Customer timeline"}</span><span>Sample view</span></div>
        <svg viewBox="0 0 320 75" preserveAspectRatio="none">
          <path className="preview-gridline" d="M0 15H320 M0 37H320 M0 59H320" />
          {project.visual === "fraud" && <>
            <path className="preview-line-muted" d="M5 54 C35 51 40 35 70 42 S110 58 145 36 S192 45 225 24 S270 38 315 13" />
            <path className="preview-line" d="M5 63 C45 58 66 61 95 53 S142 62 176 48 S229 59 262 44 S295 49 315 41" />
            <circle className="preview-point" cx="225" cy="24" r="3" /><circle className="preview-point" cx="281" cy="16" r="3" />
          </>}
          {project.visual === "forecast" && <>
            <path className="preview-line" d="M5 56 C30 51 38 59 60 45 S94 42 113 48 S145 25 169 34 S201 45 220 30" />
            <path className="preview-forecast" d="M220 30 C247 25 260 38 281 23 S300 20 315 15" />
            <path className="preview-range" d="M220 30 L315 3 L315 32Z" />
          </>}
          {project.visual === "funnel" && <>
            <rect className="preview-funnel-step" x="12" y="13" width="296" height="9" rx="2" />
            <rect className="preview-funnel-step alt" x="34" y="31" width="252" height="9" rx="2" />
            <rect className="preview-funnel-step" x="62" y="49" width="196" height="9" rx="2" />
            <rect className="preview-funnel-step alt" x="94" y="67" width="132" height="6" rx="2" />
          </>}
          {project.visual === "sentiment" && <>
            <path className="preview-line-muted" d="M5 53 C42 48 55 39 88 45 S131 32 163 37 S208 26 240 31 S283 19 315 22" />
            <g className="preview-sentiment-bars"><rect x="15" y="48" width="8" height="20" rx="2"/><rect x="42" y="38" width="8" height="30" rx="2"/><rect x="69" y="44" width="8" height="24" rx="2"/><rect x="96" y="29" width="8" height="39" rx="2"/><rect x="123" y="35" width="8" height="33" rx="2"/><rect x="150" y="22" width="8" height="46" rx="2"/><rect x="177" y="31" width="8" height="37" rx="2"/><rect x="204" y="17" width="8" height="51" rx="2"/><rect x="231" y="24" width="8" height="44" rx="2"/><rect x="258" y="12" width="8" height="56" rx="2"/><rect x="285" y="18" width="8" height="50" rx="2"/></g>
          </>}
          {project.visual === "retention" && <>
            <path className="preview-line-muted" d="M5 17 C32 18 43 23 67 25 S105 34 128 35 S167 42 191 43 S223 50 246 53 S286 59 315 63" />
            <path className="preview-line" d="M5 24 C35 21 48 31 73 29 S111 37 135 39 S168 34 194 47 S230 43 255 54 S286 49 315 58" />
            <circle className="preview-point" cx="194" cy="47" r="3" /><circle className="preview-point" cx="255" cy="54" r="3" />
          </>}
        </svg>
      </div>
      <div className="preview-caption"><span>PROJECT SCENARIO</span><span>NO RESULTS CLAIMED</span></div>
    </div>
  );
}

function formatAhmedabadTime() {
  return new Intl.DateTimeFormat("en-IN", { timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).format(new Date());
}

function getAhmedabadGreeting() {
  const hour = Number(new Intl.DateTimeFormat("en-IN", { timeZone: "Asia/Kolkata", hour: "2-digit", hourCycle: "h23" }).format(new Date()));
  if (hour < 12) return "Good morning";
  if (hour < 17) return "Good afternoon";
  if (hour < 21) return "Good evening";
  return "Good night";
}

function BrandIcon({ name }: { name: "github" | "linkedin" }) {
  return name === "github" ? (
    <svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 .8a11.2 11.2 0 0 0-3.54 21.83c.56.1.76-.24.76-.54v-2.1c-3.1.67-3.76-1.32-3.76-1.32-.5-1.29-1.24-1.64-1.24-1.64-1.01-.69.08-.68.08-.68 1.12.08 1.71 1.15 1.71 1.15 1 .1.77 2.03 2.65 1.54.1-.72.39-1.21.7-1.49-2.48-.28-5.09-1.24-5.09-5.52 0-1.22.44-2.22 1.15-3-.12-.28-.5-1.42.11-2.96 0 0 .94-.3 3.08 1.15a10.7 10.7 0 0 1 5.61 0c2.14-1.45 3.07-1.15 3.07-1.15.62 1.54.23 2.68.12 2.96.72.78 1.15 1.78 1.15 3.01 0 4.29-2.62 5.23-5.12 5.5.4.35.75 1.03.75 2.08v3.08c0 .3.2.65.76.54A11.2 11.2 0 0 0 12 .8Z" /></svg>
  ) : (
    <svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M19 3a2 2 0 1 1 0 4 2 2 0 0 1 0-4ZM4 8h4v13H4zm6 0h3.8v1.8h.1A4.2 4.2 0 0 1 17.7 7c4.2 0 5 2.7 5 6.2V21h-4v-6.9c0-1.7 0-3.9-2.4-3.9s-2.8 1.9-2.8 3.8V21h-4V8ZM2 8h4v13H2z" /></svg>
  );
}

function ProjectModal({ project, onClose }: { project: PortfolioProject; onClose: () => void }) {
  useEffect(() => {
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const closeButton = document.querySelector<HTMLButtonElement>(".case-close");
    closeButton?.focus();
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
      if (event.key === "Tab") {
        const focusable = document.querySelectorAll<HTMLElement>(".case-modal button:not(:disabled), .case-modal a[href]");
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      }
    };
    document.addEventListener("keydown", onKeyDown);
    document.body.classList.add("modal-open");
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.body.classList.remove("modal-open");
      previousFocus?.focus();
    };
  }, [onClose]);

  return (
    <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="case-modal" style={{ "--project-accent": project.accent } as CSSProperties} role="dialog" aria-modal="true" aria-labelledby="case-title" tabIndex={-1}>
        <div className="case-modal-top">
          <span className="case-label"><i /> ILLUSTRATIVE CASE STUDY</span>
          <button className="icon-button case-close" onClick={onClose} aria-label="Close case study"><X size={18} /></button>
        </div>
        <div className="case-heading"><span className="eyebrow">PROJECT {project.number} <i>·</i> {project.category}</span><h2 id="case-title">{project.title}</h2><p>{project.summary}</p></div>
        <ProjectPreview project={project} />
        <div className="case-context"><span className="case-context-label">THE SCENARIO</span><p>{project.scenario}</p></div>
        <div className="case-dataset"><div><span className="case-context-label">DATASET & CONTEXT</span><h3>{project.dataset}</h3><p>{project.datasetNote}</p></div><a href={project.datasetUrl} target="_blank" rel="noreferrer">Open source dataset <ArrowUpRight size={13} /></a></div>
        <div className="case-tech">{project.technologies.map((technology) => <span key={technology}>{technology}</span>)}</div>
        <section className="case-plan"><span className="case-context-label">BUILD CHECKLIST</span><ol>{project.buildPlan.map((item, index) => <li key={item}><span>{String(index + 1).padStart(2, "0")}</span>{item}</li>)}</ol></section>
        <div className="case-sections">{project.sections.map((section, index) => <article key={section.title}><span className="case-section-index">{String(index + 1).padStart(2, "0")}</span><div><h3>{section.title}</h3><p>{section.detail}</p></div></article>)}</div>
        <div className="case-actions"><span>Scenario-based portfolio study · results are not represented as completed findings.</span></div>
      </section>
    </div>
  );
}

export default function Index() {
  const [theme, setTheme] = useState<Theme>(() => localStorage.getItem("portfolio-theme") === "light" ? "light" : "dark");
  const [filter, setFilter] = useState<ProjectFilter>("All projects");
  const [activeProject, setActiveProject] = useState<PortfolioProject | null>(null);
  const [activeNav, setActiveNav] = useState("home");
  const [introRoleIndex, setIntroRoleIndex] = useState(0);
  const [ahmedabadTime, setAhmedabadTime] = useState("--:--:--");
  const [timeGreeting, setTimeGreeting] = useState("Good day");

  useEffect(() => {
    document.documentElement.dataset.theme = theme === "light" ? "paper" : "midnight";
    document.querySelector<HTMLMetaElement>('meta[name="theme-color"]')?.setAttribute("content", theme === "light" ? "#f3f2ec" : "#101217");
    localStorage.setItem("portfolio-theme", theme);
  }, [theme]);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const interval = window.setInterval(() => setIntroRoleIndex((index) => (index + 1) % introRoles.length), 3000);
    return () => window.clearInterval(interval);
  }, []);

  useEffect(() => {
    const updateTime = () => {
      setAhmedabadTime(formatAhmedabadTime());
      setTimeGreeting(getAhmedabadGreeting());
    };
    updateTime();
    const interval = window.setInterval(updateTime, 1000);
    return () => window.clearInterval(interval);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) setActiveNav(entry.target.id);
      });
    }, { rootMargin: "-35% 0px -58% 0px" });
    document.querySelectorAll("main section[id]").forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const updatePointer = (event: MouseEvent) => {
      document.documentElement.style.setProperty("--pointer-x", `${event.clientX}px`);
      document.documentElement.style.setProperty("--pointer-y", `${event.clientY}px`);
    };
    window.addEventListener("mousemove", updatePointer, { passive: true });
    return () => window.removeEventListener("mousemove", updatePointer);
  }, []);

  const visibleProjects = useMemo(() => {
    if (filter === "All projects") return projects;
    const tag = filter === "Analytics" ? "Data Analytics" : filter;
    return projects.filter((project) => project.tags.includes(tag));
  }, [filter]);
  const toggleTheme = () => setTheme((current) => current === "dark" ? "light" : "dark");
  const closeProject = useCallback(() => setActiveProject(null), []);

  return (
    <div className="portfolio-app">
      <div className="app-shell">
        <header className="topbar">
          <a className="brand-lockup" href="#home" aria-label="Shivansh Srivastava, home"><span className="brand-mark">S<span>.</span></span><span className="brand-name">SHIVANSH<span> SRIVASTAVA</span></span></a>
          <nav className="desktop-nav" aria-label="Main navigation">{navigation.map((item) => <a key={item.href} href={item.href} className={activeNav === item.href.slice(1) ? "active" : ""}>{item.label}</a>)}</nav>
          <div className="top-actions">
            <a href="#resume" className="header-resume">Resume <ArrowUpRight size={13} /></a>
            <button className="theme-toggle" onClick={toggleTheme} aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} theme`}><span className={`theme-toggle-mark ${theme}`} /><span>{theme === "dark" ? "Dark" : "Light"}</span></button>
            <details className="mobile-menu"><summary aria-label="Open navigation menu"><span /><span /></summary><nav aria-label="Mobile navigation">{navigation.map((item) => <a key={item.href} href={item.href} onClick={(event) => { event.currentTarget.closest("details")?.removeAttribute("open"); }}>{item.label}</a>)}<a href="#resume" onClick={(event) => { event.currentTarget.closest("details")?.removeAttribute("open"); }}>Resume</a></nav></details>
          </div>
        </header>

        <main>
          <section className="hero-section" id="home">
            <div className="hero-copy">
              <div className="eyebrow"><span className="eyebrow-mark" /><span className="hero-greeting">{timeGreeting}</span><i>·</i> DATA ANALYTICS <i>·</i> DATA SCIENCE</div>
              <h1>Shivansh<br /><span>Srivastava.</span></h1>
              <p className="hero-role" aria-live="off"><span key={introRoleIndex} className="role-transition">{introRoles[introRoleIndex]}</span></p>
              <p className="hero-description">I use data to answer practical questions, spot useful patterns, and help teams decide what to do next.</p>
              <div className="hero-time"><span className="availability-live" aria-label={`Current local time: ${ahmedabadTime} India Standard Time`}><i /> Live · {ahmedabadTime} IST</span></div>
              <div className="hero-actions"><a className="button-primary" href="#projects">View projects <ArrowDownRight size={15} /></a><a className="button-secondary" href="#resume">Resume · coming soon <ArrowDown size={14} /></a></div>
              <div className="hero-socials"><a href={githubUrl} target="_blank" rel="noreferrer"><BrandIcon name="github" />GitHub<ArrowUpRight size={11} /></a><a href={linkedInUrl} target="_blank" rel="noreferrer"><BrandIcon name="linkedin" />LinkedIn<ArrowUpRight size={11} /></a><a href="mailto:shivanshsrivastava011@gmail.com"><Mail size={14} />Email<ArrowUpRight size={11} /></a></div>
            </div>
            <div className="hero-photo-wrap"><figure className="hero-photo"><img src={profilePhoto} alt="Shivansh Srivastava" /></figure><article className="education-card"><span className="education-mark">ED</span><div><span className="experience-label">EDUCATION</span><h2>Government Engineering College, Palanpur</h2><p>Bachelor of Engineering in Computer Engineering</p><time>Aug 2023 – Apr 2027</time></div></article></div>
            <a className="hero-scroll" href="#about"><span>GET TO KNOW ME</span><ArrowDown size={14} /></a>
          </section>

          <section className="about-section section-block" id="about">
            <div className="about-intro"><span className="section-kicker">01 / ABOUT</span><h2>About <span>me.</span></h2><p>I’m a B.Tech Computer Engineering student (2023–2027) at Government Engineering College, Palanpur, Gujarat, and a Data Analyst at Napsa Solutions, where I’ve been working since March 2026. I enjoy turning raw, untidy datasets into clear business insight.</p><p>My day-to-day work spans SQL queries, Python analysis, dashboarding, and stakeholder reporting. I’m also growing my experience applying AI and machine learning to practical business questions such as churn prediction and demand forecasting.</p><p>I’m always building, with several data analytics and AI-driven projects underway to sharpen both my analytical and business thinking. I’m open to full-time and internship opportunities.</p></div>
            <div className="about-aside"><span className="aside-label">AREAS OF FOCUS</span><div><span>01</span> Business & product analytics</div><div><span>02</span> Statistical analysis</div><div><span>03</span> Applied machine learning</div><div><span>04</span> Data visualization & BI</div></div>
          </section>

          <section className="work-section section-block" id="projects">
            <div className="section-heading"><div><span className="section-kicker">02 / SELECTED PROJECTS</span><h2>Recent <span>projects.</span></h2><p>Selected projects across customer analytics, fraud detection, forecasting, product behavior, and NLP.</p></div><span className="project-count">{String(projects.length).padStart(2, "0")} PROJECTS</span></div>
            <div className="filter-bar" role="group" aria-label="Filter projects">{filters.map((item) => <button key={item} onClick={() => setFilter(item)} className={filter === item ? "selected" : ""} aria-pressed={filter === item}>{item}</button>)}</div>
            <div className="project-grid">{visibleProjects.map((project) => <article className="project-card" key={project.id} style={{ "--project-accent": project.accent } as CSSProperties} role="button" tabIndex={0} aria-haspopup="dialog" aria-label={`Open ${project.title} case study`} onClick={() => setActiveProject(project)} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); setActiveProject(project); } }}>
              <div className="project-card-top"><span className="project-number">PROJECT {project.number}</span><span className="project-status"><i /> CASE STUDY</span></div>
              <ProjectPreview project={project} />
              <div className="project-content"><div className="project-category">{project.category.toUpperCase()}</div><h3>{project.title}</h3><p>{project.summary}</p><div className="project-scope"><span>SCENARIO</span><b>{project.scenario}</b></div><div className="project-workflow" aria-label={`Project workflow: ${project.workflow.join(", ")}`}>{project.workflow.map((step, index) => <span key={step}><i>{String(index + 1).padStart(2, "0")}</i>{step}</span>)}</div><div className="project-tech">{project.technologies.map((technology) => <span key={technology}>{technology}</span>)}</div><div className="project-card-footer"><span className="case-link">Read the case study <ArrowUpRight size={14} /></span><span>{project.dataset}</span></div></div>
            </article>)}</div>
          </section>

          <section className="skills-section section-block" id="skills">
            <div className="section-heading"><div><span className="section-kicker">03 / SKILLS</span><h2>Tools for the <span>work.</span></h2><p>A practical toolkit across the analysis lifecycle.</p></div></div>
            <div className="skills-groups">{skillGroups.map((group, index) => <article className="skill-group" key={group.name}><div className="skill-group-head"><span>{String(index + 1).padStart(2, "0")}</span><h3>{group.name}</h3></div><div className="skill-chips">{group.skills.map((skill) => <span key={skill}>{skill}</span>)}</div></article>)}</div>
          </section>

          <section className="experience-section section-block" id="experience">
            <div className="section-heading compact-heading"><div><span className="section-kicker">04 / EXPERIENCE</span><h2>Professional <span>experience.</span></h2></div></div>
            <div className="experience-grid"><article className="experience-entry"><div className="experience-entry-head"><div><span className="experience-label">NAPSA SOLUTIONS</span><h3>Data Analyst</h3></div><time>Mar 2026 – Present</time></div><ul><li>Collect, clean, and validate data for analysis and reporting.</li><li>Use SQL and Python to investigate trends and answer business questions.</li><li>Build clear dashboards and recurring reports around useful KPIs.</li><li>Share findings with stakeholders and connect analysis to practical next steps.</li><li>Monitor data quality and document assumptions behind metrics.</li></ul></article></div>
          </section>

          <section className="resume-section section-block" id="resume">
            <div><span className="section-kicker">05 / RESUME</span><h2>My <span>resume.</span></h2><p>A detailed resume will be available here soon.</p></div><div className="resume-actions"><button className="button-primary disabled-button" disabled><ArrowDown size={15} /> Download resume <span>Coming soon</span></button><button className="resume-view" disabled>View resume <ExternalLink size={13} /><span>Coming soon</span></button></div>
          </section>

          <section className="contact-section section-block" id="contact">
            <div className="contact-intro"><span className="section-kicker">06 / CONTACT</span><h2>Let’s <span>connect.</span></h2><p>I’m open to opportunities in data analytics, data science, business and product analytics, and applied machine learning.</p></div>
            <div className="contact-links"><a className="contact-row" href="mailto:shivanshsrivastava011@gmail.com"><span className="contact-icon"><Mail size={15} /></span><span><small>EMAIL</small><b>shivanshsrivastava011@gmail.com</b></span><ArrowUpRight size={15} /></a><a className="contact-row" href="tel:+918470887439"><span className="contact-icon"><Phone size={15} /></span><span><small>PHONE</small><b>+91 84708 87439</b></span><ArrowUpRight size={15} /></a><a className="contact-row" href={linkedInUrl} target="_blank" rel="noreferrer"><span className="contact-icon"><BrandIcon name="linkedin" /></span><span><small>LINKEDIN</small><b>Connect on LinkedIn</b></span><ArrowUpRight size={15} /></a><a className="contact-row" href={githubUrl} target="_blank" rel="noreferrer"><span className="contact-icon"><BrandIcon name="github" /></span><span><small>GITHUB</small><b>View GitHub profile</b></span><ArrowUpRight size={15} /></a></div>
          </section>
        </main>

        <footer className="footer"><span className="footer-copyright">© 2026 Shivansh Srivastava</span><span className="footer-focus">DATA ANALYTICS · DATA SCIENCE · APPLIED ML</span></footer>
      </div>
      {activeProject && <ProjectModal project={activeProject} onClose={closeProject} />}
    </div>
  );
}
