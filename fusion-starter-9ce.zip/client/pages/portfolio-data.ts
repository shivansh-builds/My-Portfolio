export type PortfolioProject = {
  id: string;
  number: string;
  title: string;
  category: string;
  tags: string[];
  summary: string;
  scenario: string;
  dataset: string;
  datasetNote: string;
  datasetUrl: string;
  technologies: string[];
  previewMetrics: [string, string, string];
  visual: "retention" | "fraud" | "forecast" | "funnel" | "sentiment";
  accent: string;
  workflow: [string, string, string];
  buildPlan: string[];
  sections: { title: string; detail: string }[];
};

export const projects: PortfolioProject[] = [
  {
    id: "customer-churn",
    number: "01",
    title: "Customer Churn & Retention Analytics",
    category: "Customer analytics · SQL · Python",
    tags: ["Data Analytics", "Machine Learning", "Python", "SQL"],
    summary: "A closer look at repeat-purchase behavior—and the difference between a quiet customer and a lost one.",
    scenario: "A small online retailer wants to spot customers whose buying rhythm has changed, then decide which groups are worth a thoughtful retention test. The analysis starts with behavior the invoices can actually show; it does not pretend that a purchase gap is a confirmed cancellation.",
    dataset: "UCI Online Retail II",
    datasetNote: "More than one million transaction records from a UK-based online retailer, covering December 2009 to December 2011. The source includes cancellations and missing customer IDs, so the usable population needs to be stated rather than quietly assumed.",
    datasetUrl: "https://archive.ics.uci.edu/dataset/502/online+retail+ii",
    technologies: ["SQL", "Python", "Pandas", "Cohort analysis", "Power BI"],
    previewMetrics: ["Repeat rate", "Purchase cadence", "Customer value"],
    visual: "retention",
    accent: "#55c6a6",
    workflow: ["Audit invoices", "Compare cohorts", "Frame retention tests"],
    buildPlan: [
      "Profile invoices and customer IDs; record how cancellations, returns, and missing IDs are treated.",
      "Create a reusable SQL transaction layer and a documented customer-month table.",
      "Calculate cohort retention, repeat-purchase intervals, recency/frequency/value, and sensitivity to different inactivity windows.",
      "Review segments for size and stability; check whether each group has enough history to compare fairly.",
      "Deliver a Power BI view, data-quality notes, metric definitions, and a testable retention question for each priority segment.",
    ],
    sections: [
      { title: "The question", detail: "Which customers are returning less often than their own earlier pattern, and how early can that change be noticed without labeling every quiet account as churned?" },
      { title: "Start with clean transactions", detail: "Set the invoice and customer grain, separate cancellation records, check quantities and prices, and report how missing customer IDs affect each view. Keep the cleaning rules visible so another analyst can reproduce the customer totals." },
      { title: "Read the customer timeline", detail: "Use monthly cohorts, repeat-purchase intervals, and recency/frequency/value summaries to describe how behavior changes over time. Compare customers with similar tenure instead of treating one universal inactivity window as a fact." },
      { title: "Turn patterns into a test", detail: "Create a reviewable list of customers whose purchase cadence has shifted, then suggest small, segment-specific outreach tests. A holdout group would be needed before attributing any improvement to a campaign." },
      { title: "Tools and hand-off", detail: "SQL is suited to the transaction-level checks and customer summaries; Python supports repeatable exploration; a Power BI view can let a commercial team inspect cohorts and segment definitions." },
      { title: "What this dataset cannot say", detail: "There is no direct churn label or record of marketing interventions. This is an inactivity-proxy and retention-analysis scenario, not a validated churn prediction or a claim that a campaign recovered revenue." },
    ],
  },
  {
    id: "fraud-detection",
    number: "02",
    title: "Financial Fraud & Transaction Anomaly Detection",
    category: "Fraud analytics · Imbalanced learning",
    tags: ["Data Science", "Machine Learning", "Python", "SQL"],
    summary: "Design an alerting approach that takes rare cases seriously without burying reviewers in false alarms.",
    scenario: "A payments team has limited investigation time. It needs a way to rank unusual transfers for review, while keeping the cost of missed cases and noisy alerts visible to the people who set the threshold.",
    dataset: "PaySim synthetic mobile-money transactions",
    datasetNote: "PaySim is a simulator-generated dataset introduced in research on mobile-money fraud detection. It is useful for practicing imbalanced classification, but simulated behavior is not a substitute for real payment operations or real-world fraud prevalence.",
    datasetUrl: "https://www.kaggle.com/datasets/ealaxi/paysim1",
    technologies: ["Python", "Pandas", "Scikit-learn", "SQL", "PR-AUC"],
    previewMetrics: ["Alert volume", "Precision / recall", "Review queue"],
    visual: "fraud",
    accent: "#f28b72",
    workflow: ["Check leakage", "Rank alert queue", "Review false alarms"],
    buildPlan: [
      "Inspect label balance, transaction types, time steps, and available balance fields before choosing features.",
      "Build a chronological train/validation/test split and write down the point-in-time feature rules.",
      "Compare a simple baseline with logistic regression, a tree-based model, and an anomaly-ranking approach.",
      "Report precision, recall, PR-AUC, confusion counts, and alert volume at thresholds tied to review capacity.",
      "Deliver an error-review notebook and a short model card covering leakage checks, synthetic-data limits, and human-review needs.",
    ],
    sections: [
      { title: "The question", detail: "How should a review queue prioritize suspicious activity when positive examples are rare and investigator capacity is finite? The useful result is a defensible ranking and threshold discussion—not a headline accuracy score." },
      { title: "Understand the simulation", detail: "Inspect transaction types, labels, time steps, and balance fields first. Document that PaySim is synthetic, and avoid presenting its class mix or patterns as representative of any real bank." },
      { title: "Build a fair comparison", detail: "Start with a simple logistic-regression baseline, then compare a tree-based classifier and an anomaly-detection option. Check for label leakage in engineered features before interpreting model behavior." },
      { title: "Evaluate at the review desk", detail: "Use a time-aware holdout where the data permits it. Compare precision, recall, PR-AUC, and the number of cases surfaced at candidate thresholds; inspect false positives as well as missed cases." },
      { title: "Make the output usable", detail: "Show why a transaction was ranked, summarize alert volume by transaction type, and give reviewers a threshold they can discuss against a stated daily capacity. Any production decision would need local validation and human review." },
      { title: "Limitations", detail: "Synthetic transactions simplify the behavior and context of real payments. Model scores from this exercise would be educational results only and must not be presented as evidence of real fraud-detection performance." },
    ],
  },
  {
    id: "sales-forecasting",
    number: "03",
    title: "Sales Forecasting & Business Intelligence",
    category: "Business intelligence · Time series",
    tags: ["Data Analytics", "Time Series", "SQL", "Power BI", "Python"],
    summary: "Give a planning team a clear view of weekly product demand, with forecast uncertainty kept in the conversation.",
    scenario: "A merchandising team has to plan stock across a broad product range. It needs to know which items move steadily, which have uneven weekly demand, and where a forecast is too uncertain to use as a promise.",
    dataset: "UCI Sales Transactions Dataset Weekly",
    datasetNote: "The UCI dataset contains weekly purchase quantities for 811 products across 52 weeks, with normalized values also provided. Its short, normalized series are useful for exploring product patterns, but they do not provide the context needed for a live inventory plan or a long seasonal history.",
    datasetUrl: "https://archive.ics.uci.edu/dataset/396/sales+transactions+dataset+weekly",
    technologies: ["SQL", "Python", "Pandas", "Time-series validation", "Power BI"],
    previewMetrics: ["Weekly demand", "Forecast range", "Error by horizon"],
    visual: "forecast",
    accent: "#e5b85c",
    workflow: ["Profile series", "Backtest forecasts", "Build planner view"],
    buildPlan: [
      "Confirm the product-by-week grain and distinguish original quantities from normalized values.",
      "Audit missing periods, zero-heavy items, and unusual sequences before grouping products by demand shape.",
      "Compare last-period and moving-average baselines with one suitable time-series method.",
      "Use rolling-origin backtests and report error by product group and forecast horizon; avoid one blended score hiding weak segments.",
      "Deliver a Power BI planning view with actual history, an explicitly illustrative forecast range, error context, and a data limitations note.",
    ],
    sections: [
      { title: "The question", detail: "Can a simple, explainable weekly baseline help a planner compare product demand patterns—and where does it stop being reliable enough to guide replenishment?" },
      { title: "Respect the shape of the data", detail: "Check the product/week grain, missing or zero periods, and the meaning of normalized quantities before aggregating. Keep the original and normalized values separate so the dashboard does not imply sales currency or units that are not present." },
      { title: "Set a baseline first", detail: "Compare a naïve last-period forecast and a moving-average baseline before trying a seasonal method. Segment products by observed pattern so one quiet item does not dictate a single forecast strategy for all 811." },
      { title: "Backtest instead of guessing", detail: "Use rolling time splits to compare forecast error at more than one horizon. Report the error by product group and show where the series is too intermittent or too short to support a useful estimate." },
      { title: "A planner-friendly view", detail: "A Power BI page can pair observed weekly patterns with a clearly marked forecast range, recent error, and a product selector. The purpose is to support a conversation about stock risk, not to disguise uncertainty behind a smooth line." },
      { title: "Limitations", detail: "Fifty-two weeks cannot establish multi-year seasonality, and normalized quantities should not be read as actual revenue or inventory units. A real planning recommendation would need dates, stockouts, promotions, lead times, and business context." },
    ],
  },
  {
    id: "product-analytics",
    number: "04",
    title: "Product & Customer Behavior Analytics",
    category: "Product analytics · Event data",
    tags: ["Product Analytics", "Data Analytics", "SQL", "Python"],
    summary: "Map a sample shopping journey carefully, from the first recorded event to the moments that precede a purchase.",
    scenario: "A product team wants to understand where shoppers progress or fall away in an online journey. Before changing the experience, the team needs consistent event definitions and a funnel that does not mistake missing tracking for user intent.",
    dataset: "Google Analytics obfuscated ecommerce sample",
    datasetNote: "Google's public BigQuery sample represents ecommerce event data from November 1, 2020 through January 31, 2021. Google notes that the data is obfuscated and may have limited internal consistency; this makes it a learning dataset, not a trustworthy report on the store's actual performance.",
    datasetUrl: "https://developers.google.com/analytics/bigquery/web-ecommerce-demo-dataset",
    technologies: ["BigQuery SQL", "GA4 event schema", "Python", "Funnel analysis", "Looker Studio"],
    previewMetrics: ["Event coverage", "Journey steps", "Purchase path"],
    visual: "funnel",
    accent: "#a78bfa",
    workflow: ["Define events", "Validate funnel", "Surface next questions"],
    buildPlan: [
      "Map relevant GA4 event and item fields from the documented export schema before naming funnel steps.",
      "Define identity, session boundaries, event order, conversion window, and repeat-event rules in a metric spec.",
      "Query event coverage and placeholder values so instrumentation gaps do not masquerade as user drop-off.",
      "Build step progression and available breakdowns in BigQuery, validating each cut against the sample limitations.",
      "Deliver reusable SQL, an annotated funnel view, and follow-up usability questions rather than unsupported causal claims.",
    ],
    sections: [
      { title: "The question", detail: "Which recorded steps make up a useful shopping journey, and what can the event stream genuinely tell a product team about progression through that journey?" },
      { title: "Define before counting", detail: "Read the GA4 export schema, inspect event and item fields, and choose a session or user-level rule before building a funnel. Make the time window and treatment of repeat events explicit." },
      { title: "Check instrumentation", detail: "Compare event coverage across the sample, look for missing or placeholder values, and check whether the available fields support each proposed step. Keep tracking gaps separate from observed drop-off." },
      { title: "Explore the journey", detail: "Use BigQuery SQL to build a consistent step sequence, then compare the available paths or device dimensions only where the fields are present and interpretable. Describe associations rather than claiming an interface change caused a conversion difference." },
      { title: "Give the team a next question", detail: "A compact dashboard can show the defined funnel, event coverage, and the largest observed step-to-step changes. Those patterns help prioritize a usability question for user research or a properly designed experiment." },
      { title: "Limitations", detail: "The sample covers only three months and is obfuscated. Its internal inconsistencies rule out treating the displayed rates as current, authoritative store KPIs or comparing them with Google's Demo Account." },
    ],
  },
  {
    id: "customer-feedback",
    number: "05",
    title: "Customer Feedback & Sentiment Analysis",
    category: "Natural language processing · Reviews",
    tags: ["NLP", "Data Science", "Python", "Machine Learning"],
    summary: "Pair a simple sentiment baseline with the original review text, so a score never replaces the customer’s words.",
    scenario: "A support or product team receives more short reviews than it can comfortably scan each week. This study explores whether sentiment and recurring terms can help organize a first read—while keeping individual comments and model mistakes easy to inspect.",
    dataset: "UCI Sentiment Labelled Sentences",
    datasetNote: "The dataset contains 3,000 labeled sentences drawn evenly from IMDb, Amazon, and Yelp. Its compact, balanced, sentence-level examples are useful for a baseline exercise, but they do not represent the volume, language mix, or sentiment prevalence of a real support inbox.",
    datasetUrl: "https://archive.ics.uci.edu/dataset/331/sentiment+labelled+sentences",
    technologies: ["Python", "Pandas", "TF-IDF", "Scikit-learn", "Error analysis"],
    previewMetrics: ["Sentiment mix", "Common phrases", "Review examples"],
    visual: "sentiment",
    accent: "#e77daa",
    workflow: ["Preserve context", "Compare baselines", "Review model errors"],
    buildPlan: [
      "Keep original sentence, source platform, and label together while documenting any normalization or duplicate handling.",
      "Set up a source-aware train/test split and compare a simple lexicon baseline with TF-IDF logistic regression.",
      "Report per-class precision, recall, F1, and a confusion matrix instead of relying on accuracy alone.",
      "Read false positives and false negatives by platform; tag examples involving negation, sarcasm, and mixed sentiment.",
      "Deliver an error-review notebook and a human-review dashboard that shows example sentences beside any aggregate theme.",
    ],
    sections: [
      { title: "The question", detail: "Can a transparent text baseline help a team find broad themes in short feedback, and which important nuances disappear when language is reduced to positive or negative?" },
      { title: "Keep the source in view", detail: "Preserve the original sentence, platform, and label while checking duplicates and text preparation. Compare the three review sources separately before presenting a combined view." },
      { title: "Start with an interpretable model", detail: "Build a TF-IDF plus logistic-regression baseline, compare it with a simple lexicon view, and inspect frequent terms in context. Avoid treating raw word frequency as a topic or customer priority." },
      { title: "Inspect the mistakes", detail: "Use class-aware metrics and a held-out split, then read false positives and false negatives by hand. Sarcasm, negation, mixed opinions, and platform-specific language are useful examples to surface rather than hide." },
      { title: "Make a review aid, not a verdict", detail: "Present sentiment as a filter for human review, alongside representative original sentences and recurring phrases. A team should confirm a theme in the text before changing a product or service." },
      { title: "Limitations", detail: "The corpus is small, balanced, and limited to short sentences from three platforms. Its scores cannot be transferred to a different brand, language, support channel, or current customer base without new labeled data and validation." },
    ],
  },
];

export const skillGroups = [
  { name: "Data Analytics", skills: ["SQL", "Advanced Excel", "Pandas", "NumPy", "Data Cleaning", "EDA", "Statistical Analysis", "KPI Analysis", "Cohort Analysis", "Funnel Analysis"] },
  { name: "Data Science", skills: ["Python", "Statistics", "Probability", "Hypothesis Testing", "Feature Engineering", "Predictive Modeling", "Model Evaluation", "Cross Validation"] },
  { name: "Machine Learning", skills: ["Scikit-learn", "Regression", "Classification", "Clustering", "Anomaly Detection", "Time Series", "NLP"] },
  { name: "Visualization & BI", skills: ["Power BI", "Matplotlib", "Seaborn", "Plotly", "Dashboard Design", "Data Storytelling"] },
  { name: "Tools", skills: ["Git", "GitHub", "Jupyter", "Docker", "Workbench", "Advanced Excel"] },
];
